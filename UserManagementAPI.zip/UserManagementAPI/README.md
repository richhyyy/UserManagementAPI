# UserManagementAPI

A simple ASP.NET Core Minimal API for managing users (CRUD), with validation, request logging middleware, and global exception handling.

## Requirements
- .NET 8 SDK or newer
- Optional: Postman for testing

## Run locally
```bash
dotnet restore
dotnet run --urls http://localhost:5080
```

Open `http://localhost:5080/` to check the API is running.

## Endpoints
| Method | Route | Purpose |
|---|---|---|
| GET | `/api/users` | List users |
| GET | `/api/users/{id}` | Get one user |
| POST | `/api/users` | Create a user |
| PUT | `/api/users/{id}` | Update a user |
| DELETE | `/api/users/{id}` | Delete a user |

## Example POST body
```json
{
  "name": "Richa Lopes",
  "email": "richa@example.com"
}
```

## Test with curl
```bash
curl http://localhost:5080/api/users
curl -X POST http://localhost:5080/api/users -H "Content-Type: application/json" -d "{"name":"Richa Lopes","email":"richa@example.com"}"
curl http://localhost:5080/api/users/1
curl -X PUT http://localhost:5080/api/users/1 -H "Content-Type: application/json" -d "{"name":"Richa Updated","email":"richa.updated@example.com"}"
curl -i -X DELETE http://localhost:5080/api/users/1
```

## Notes
- Data is stored in memory and resets when the application restarts.
- The sample includes basic name/email validation, request logging middleware, and generic global error responses.
- Swagger support is configured; install/restore dependencies with `dotnet restore` before running.
- Review and test the code before submitting it. Update the repository URL and describe any assistance you used in accordance with your course's rules.
