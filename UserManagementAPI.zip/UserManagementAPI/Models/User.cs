namespace UserManagementAPI.Models;

public sealed record User(int Id, string Name, string Email);

public sealed record CreateUserRequest(string? Name, string? Email);

public sealed record UpdateUserRequest(string? Name, string? Email);

public interface IUserRepository
{
    IReadOnlyCollection<User> GetAll();
    User? GetById(int id);
    User Create(string name, string email);
    User? Update(int id, string name, string email);
    bool Delete(int id);
}

public sealed class InMemoryUserRepository : IUserRepository
{
    private readonly object _lock = new();
    private readonly Dictionary<int, User> _users = new();
    private int _nextId = 1;

    public IReadOnlyCollection<User> GetAll()
    {
        lock (_lock) return _users.Values.OrderBy(u => u.Id).ToArray();
    }

    public User? GetById(int id)
    {
        lock (_lock) return _users.GetValueOrDefault(id);
    }

    public User Create(string name, string email)
    {
        lock (_lock)
        {
            var user = new User(_nextId++, name, email);
            _users[user.Id] = user;
            return user;
        }
    }

    public User? Update(int id, string name, string email)
    {
        lock (_lock)
        {
            if (!_users.ContainsKey(id)) return null;
            var user = new User(id, name, email);
            _users[id] = user;
            return user;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock) return _users.Remove(id);
    }
}
