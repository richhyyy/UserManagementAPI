using UserManagementAPI.Middleware;
using UserManagementAPI.Models;

var builder = WebApplication.CreateBuilder(args);

// Register services
builder.Services.AddSingleton<IUserRepository, InMemoryUserRepository>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Logging middleware
app.UseMiddleware<RequestLoggingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Global exception handling
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
        context.Response.ContentType = "application/json";
        await context.Response.WriteAsJsonAsync(new
        {
            error = "An unexpected server error occurred."
        });
    });
});

app.MapGet("/", () => Results.Ok(new
{
    message = "User Management API is running",
    endpoints = new[] { "GET /api/users", "GET /api/users/{id}", "POST /api/users", "PUT /api/users/{id}", "DELETE /api/users/{id}" }
}));

// GET all users
app.MapGet("/api/users", (IUserRepository repository) =>
    Results.Ok(repository.GetAll()));

// GET user by ID
app.MapGet("/api/users/{id:int}", (int id, IUserRepository repository) =>
{
    var user = repository.GetById(id);
    return user is null ? Results.NotFound(new { message = $"User with ID {id} was not found." }) : Results.Ok(user);
});

// POST create user
app.MapPost("/api/users", (CreateUserRequest request, IUserRepository repository) =>
{
    var errors = Validate(request.Name, request.Email);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var user = repository.Create(request.Name.Trim(), request.Email.Trim());
    return Results.Created($"/api/users/{user.Id}", user);
});

// PUT update user
app.MapPut("/api/users/{id:int}", (int id, UpdateUserRequest request, IUserRepository repository) =>
{
    var errors = Validate(request.Name, request.Email);
    if (errors.Count > 0)
        return Results.ValidationProblem(errors);

    var user = repository.Update(id, request.Name.Trim(), request.Email.Trim());
    return user is null ? Results.NotFound(new { message = $"User with ID {id} was not found." }) : Results.Ok(user);
});

// DELETE user
app.MapDelete("/api/users/{id:int}", (int id, IUserRepository repository) =>
    repository.Delete(id)
        ? Results.NoContent()
        : Results.NotFound(new { message = $"User with ID {id} was not found." }));

app.Run();

static Dictionary<string, string[]> Validate(string? name, string? email)
{
    var errors = new Dictionary<string, string[]>();
    if (string.IsNullOrWhiteSpace(name))
        errors["name"] = new[] { "Name is required." };

    if (string.IsNullOrWhiteSpace(email) ||
        !System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
        errors["email"] = new[] { "A valid email address is required." };

    return errors;
}
